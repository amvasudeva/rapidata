<!DOCTYPE html>
<html lang="en-us">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
.city {
    float: left;
    margin: 5px;
    padding: 15px;
    max-width: 300px;
    height: 300px;
    border: 1px solid black;
}
</style>
</head>
<body>
<p>
      <img src="logo.png" />
</p>

<h1>Cloudenabled DevOps Demo</h1>

<div class="city">
  <h2>India</h2>
  <p>Since 2013 in Cloud and Devops Consulting and implementation services in India.</p>
  <p>Cool to be part of Devops training.</p>
</div>
<div class="city">
  <h2>2016 Started new office in New Jersey</h2>
  <p>New Jersey is kicked off.</p>
  <p>Lets rock in New Jersey now.</p>
</div>

</body>
</html>
